 // Your web app's Firebase configuration
 // For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
    apiKey: "AIzaSyB_EoYkMeuvN7OqNerQS5laA_nkHpE5XGY",
    authDomain: "hadarfinal.firebaseapp.com",
    databaseURL: "https://hadarfinal-default-rtdb.firebaseio.com",
    projectId: "hadarfinal",
    storageBucket: "hadarfinal.appspot.com",
    messagingSenderId: "827534848366",
    appId: "1:827534848366:web:40232ad408a00e6a45d17f",
    measurementId: "G-84GYDJ92E7"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
//const db = firebase.database();

