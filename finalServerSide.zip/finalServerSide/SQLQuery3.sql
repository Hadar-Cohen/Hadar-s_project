﻿select * from Preferences_2021

delete from Preferences_2021 where userId=4 and episodeId=1304833 and seriesId=64165